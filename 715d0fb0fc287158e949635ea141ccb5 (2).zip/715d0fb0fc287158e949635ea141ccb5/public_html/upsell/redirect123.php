
<html>
<head><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><title>Спасибо!</title>
<link type="text/css" rel="stylesheet" href="../../borderStyle.css">

</head>

<body background="fon.jpg" style="color: rgb(0, 0, 0); max-width: 980px; min-width: 300px; width: auto; margin: 0px auto; background-color: rgb(255, 255, 255); font-family: pt sans,arial;">
<br>


<p>
	<img src="tel.png" style="display: block; margin: auto; width: 200px; height: 200px;" /></p>
<div class="wrap_block_success">
	<div class="block_success">
		<h2 style="text-align: center;">
			<span style="font-size:36px;">Спасибо! Ваша заявка принята, мы свяжемся с Вами как можно быстрее!<br />
			</span></h2>
		<!--<p class="success" style="text-align: center;">
			<span style="font-size:16px;">Включите свой телефон, чтобы мы могли с Вами связаться!</span></p>-->
		<h1 style="color: rgb(255, 0, 0); text-align: center;">
			<span style="font-size:36px;"></span></h1>
	</div>
</div>
<p>
	</p>
<style>
a.button24 {
  display: inline-block;
  color: white;
  text-decoration: none;
  padding: .5em 2em;
  outline: none;
  border-width: 2px 0;
  border-style: solid none;
  border-color: #FDBE33 #000 #D77206;
  border-radius: 6px;
  background: linear-gradient(#F3AE0F, #E38916) #E38916;
  transition: 0.2s;
  margin: 0 auto;
position: relative; 
 text-align: center;
    white-space: normal;
    width: auto;
    display: table;
    margin: 0 auto;
} 
a.button24:hover { background: linear-gradient(#f5ae00, #f59500) #f5ae00; }
a.button24:active { background: linear-gradient(#f59500, #f5ae00) #f59500; }
</style>
<!--<a href="./index.html" class="button24">Вернуться на сайт</a>-->

<br><br><br><br><br>

<!-- ниже код метрики (для отслеживания конверсии) -->

<!-- выше код метрики -->
<style>
.hover:hover {
	background:#9FD083 !important;
	transition:all .3s ease-in-out;
}
</style>
</body>
</html>
<?php
// Инициализируем сессию.
// Если вы используете session_name("something"), не забудьте добавить это перед session_start()!
session_start();

// Удаляем все переменные сессии.
$_SESSION = array();

// Если требуется уничтожить сессию, также необходимо удалить сессионные cookie.
// Замечание: Это уничтожит сессию, а не только данные сессии!
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Наконец, уничтожаем сессию.
session_destroy();
?>
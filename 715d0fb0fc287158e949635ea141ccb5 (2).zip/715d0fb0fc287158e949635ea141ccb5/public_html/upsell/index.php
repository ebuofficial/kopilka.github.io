<!DOCTYPE html>
<?php
session_start();
$name=$_SESSION['user_name'];
$phone=$_SESSION['user_phone'];
$dostavka=$_SESSION['user_dostavka'];

?>
<html lang="ru-RU">

<!-- Mirrored from oonies.korzinka300.ru/upsell/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 May 2019 06:30:29 GMT -->
<head>
     <title>Спецпредложение от нашего интернет-магазина, товары по супер цене! Скидки до 80%.</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,500,300italic,700&amp;subset=latin,cyrillic" rel="stylesheet" type="text/css">
    <link media="all" href="css/main_call.css" rel="stylesheet" type="text/css">
    <link media="all" href="css/hint.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.html"></script>
    <script type="text/javascript" src="js/init.js"></script>



<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<? echo (urlencode($_GET['i']));?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=<? echo (urlencode($_GET['i']));?>&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->


</head>
<body class="man">
    <script>
       fbq('track', 'Lead');  
</script>
 
 
	<div class="section block-1">
		<div class="wrap">
			<img alt="" src="img/call-girl.png">
			<div class="top-title">
				<h2>Спасибо, Ваш заказ принят!</h2>
					<div>
					Наш оператор свяжется с вами в порядки очереди&nbsp;
				</div>
				<p></p>
			</div>
		</div>
	</div>
	<div class="section block-2" id="1">
		<div class="wrap">
		<!--<h1>Обратите ВНИМАНИЕ!</h1>
		<h1>График работы с 8-00 до 17-00 Воскресенье: Выходной*</h1> -->
		<h1>Для новых клиентов у нас есть эксклюзивные предложения!</h1>
		<!--<p>Вы можете добавить эти товары с индивидуальной скидкой, к&nbsp;заказу&nbsp;прямо&nbsp;сейчас:</p>-->
		</div>
	</div>
	<style>
	.knife {
		font-weight: 700;
		font-size: 24px;
		line-height: 1.5em;
		text-align: center;
	}
	.knife2 {
		font-weight: 500;
		font-size: 20px;
		line-height: 1.5em;
		text-align: center;
	}
	</style>
	
	
	
	 <div class="section block-3">
		<div class="wrap">
				
				
				<div class="tov-item tov-rate-2 clearfix">
      
          <span class="tov-item-sale">-50%</span>
      <div class="tov-left-cont">
        <div class="tov-gal clearfix">
          <div class="tov-gal-big"><img alt="" class="02" src="img/1.jpg"></div>
        
     <div class="tov-gal-list">
                     
                        </div>
           
           </div>
    
        <ul class="tov-adv clearfix">
          <li class="hint hint--top hint--info" data-hint="Гарантия возврата 14 дней"></li>
          <li class="hint hint--top hint--info" data-hint="Доставка в течение 1-2 рабочих дней"></li>
          <li class="hint hint--top hint--info" data-hint="Оплата товара при получении"></li>
        </ul>
      </div>
      
      <div class="tov-info">
        <h3>Набор для рисования "Рисуй светом" А4 </h3>
        <div class="tov-info-rate"></div>
        <div class="tov-info-cost">
          <span class="old-cost">299<small>грн.</small></span> <span class="new-cost">149<small>грн.</small></span>
        </div>

<!--Световой планшет представляет собой фотолюминисцентный ПВХ материал в рамке, который быстро накапливает свет и затем некоторое время светится в темноте постепенно затухая.<br>-->

В комплект входит: планшет формата А4, световой маркер (специальная ручка со светодиодом), трафареты, инструкция.
 


                  <form action="send1.php" method="post">
					<input type="hidden" name="pricename" value="Дополнительный набор фотоальбомов">
							<input type="hidden" name="id" value="10">
					<input type="hidden" name="user_name" value="<?=$_GET['name'];?>">
					<input type="hidden" name="user_phone" value="<?=$_GET['phone'];?>">
					<input type="hidden" name="user_dostavka" value="<?=$_GET['dostavka'];?>">
					<button class="tov-button">Добавить к заказу</button>
					</form>

					</div>
    </div>
			

		<section>
		    <style>
		    video {
  width: 100%;
  height: auto;
  max-height: 100%;
}
</style>
	    <video width="640" height="480" controls>
	        <source src="img/2.mp4" type="video/mp4">> 
	        Это видео не включается. Обновите браузер.
	    </video>
	</section>

	
	
	<div class="section footer">
		<div class="wrap clearfix">
			<div class="left clearfix foot-logo">
				<p><b>   </b><br>
				<span>   </span></p>
			</div>
			<div class="center">
				<p>   </p>
			</div>
		</div>
	</div>  
	
</body>


				


<!-- Mirrored from oonies.korzinka300.ru/upsell/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 May 2019 06:31:06 GMT -->
</html>
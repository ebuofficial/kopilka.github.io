<?php 
//***************** Страница с завершением заказа ******************

 /* https://api.telegram.org/botXXXXXXXXXXXXXXXXXXXXXXX/getUpdates,
где, XXXXXXXXXXXXXXXXXXXXXXX - токен вашего бота, полученный ранее */
 
//Переменная $name,$phone, $mail получает данные при помощи метода POST из формы
$name = $_POST['user_name'];
$phone = $_POST['user_phone'];
$dostakva = $_POST['user_dostavka'];
 


$token = "971874524:AAGigTn5dSOIoBu1XURCdHkWOGlJ6MO-MLM";
$chat_id = "-368467774";
$arr = array(
  'ФИО 480 апсейл: ' => $name,
  'Телефон: ' => $phone,
  'Адрес: ' => $dostavka,
);
 
//При помощи цикла перебираем массив и помещаем переменную $txt текст из массива $arr
foreach($arr as $key => $value) {
  $txt .= "<b>".$key."</b> ".$value."%0A";
};
 
//Осуществляется отправка данных в переменной $sendToTelegram
$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");
 $subject = 'Новая Заявка'; // заголовок письмя
$addressat = "tronhodl@gmail.com";
$success_url = './redirect.php?name='.$_POST['user_name'].'&phone='.$_POST['user_phone'].'&dostavka='.$_POST['user_dostavka'].'';
$message = "ФИО: {$name}\Контактный телефон: {$phone}\Доставка: {$dostavka}";
$verify = mail($addressat,$subject,$message,"Content-type:text/plain;charset=utf-8\r\n");
if ($verify == 'true'){
    header('Location: '.$success_url);
    echo '<h1 style="color:green;">Поздравляем! Ваш заказ принят!</h1>';
    exit;
}
else 
    {
    echo '<h1 style="color:red;">Произошла ошибка!</h1>';
    }

?>














